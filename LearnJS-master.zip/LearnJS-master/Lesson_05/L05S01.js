//
// L05S01 - Common error messages
//
gs.info(myUnknownVariable);
ga.info('Hello, world!);
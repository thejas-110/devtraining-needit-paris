//
// L26S01 - Simple Objects
//
var box = {};
box.height   = 20;
box.width    = 10;
box.length   = 10;
box.material = "cardboard";
box.open     = true;
gs.info(box.material);
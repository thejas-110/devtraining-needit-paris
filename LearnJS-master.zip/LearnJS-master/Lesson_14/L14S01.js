//
// L14S01 - Truthy and Falsy
//

// Simple case of true and false
//
var boolTrue = true;
var boolFalse = false;
gs.info('boolTrue=' + boolTrue + ' boolFalse=' + boolFalse);
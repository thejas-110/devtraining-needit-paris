//
// L23S02 embedded forEach
//
var list = [1, 3, 5];

list.forEach(function (item) {
  gs.info('embedded function item=' + item);
});

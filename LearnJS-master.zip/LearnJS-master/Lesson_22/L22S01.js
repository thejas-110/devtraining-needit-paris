//
// L22S01 - Arrays
//

// Make a simple array
//
// Optional declaration, but not preferred:
// var list = Array();
var list = [];
list[0] = 1;
list[1] = 3;
list[2] = 5;
gs.info('length of list is: ' + list.length);
